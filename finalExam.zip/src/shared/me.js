export const Me = [{
    id: 0,
    name: 'Mook',
    image: 'photo/1.jpg',
    featured: false,
    description:""
},
{
    id: 1,
    name: 'Parisara Khongprasert',
    image: '/photo/1.jpg',
    featured: false,
    description:""
},
{
    id: 2,
    name: 'Subjects',
    image: '/photo/1.jpg',
    featured: false,
    description:""
},
{
    id: 3,
    name: 'Movies',
    image: '/photo/1.jpg',
    featured: false,
    description:""
}
] 
